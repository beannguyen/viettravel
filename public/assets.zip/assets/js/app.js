var app = angular.module('travelblog',
    [
        'ui.bootstrap',
        'ngSanitize',
        'ui.validate',
        'datatables',
        'datatables.bootstrap'
    ]
);
